package com.example.dbase;



import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;

public class Sqlitecontroller extends SQLiteOpenHelper {

	public Sqlitecontroller(Context context) {
		super(context, "simpledb.db", null, 1);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onCreate(SQLiteDatabase database) {
		// TODO Auto-generated method stub
				String query;
query="CREATE TABLE Students (StudentId INTEGER PRIMARY KEY,SName TEXT)";
database.execSQL(query);
	}

	@Override
	public void onUpgrade(SQLiteDatabase database, int old, int cur) {
		// TODO Auto-generated method stub
String query;
query="DROP TABLE IF EXISTS Students";
database.execSQL(query);
onCreate(database);
	}

}
