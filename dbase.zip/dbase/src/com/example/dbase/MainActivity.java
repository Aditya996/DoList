package com.example.dbase;

import java.util.ArrayList;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends ActionBarActivity {
    Sqlitecontroller cont= new Sqlitecontroller(this);
    SQLiteDatabase base=null;
    public Button btn_i,btn_d,btn_drop;
    public EditText e=null;
	private ListView lv;
	private ArrayAdapter<String>la;
    final ArrayList <String> serieslist = new ArrayList<String>();
    Dialog db=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        base=openOrCreateDatabase("sim.db", MODE_PRIVATE, null);
		base.execSQL("create table if not exists student(name varchar primary key);");
        lv=(ListView)findViewById(R.id.list);
        btn_i=(Button)findViewById(R.id.btn_i);
        btn_d=(Button)findViewById(R.id.btn_d);
        btn_drop=(Button)findViewById(R.id.btn_drop);
        e=(EditText)findViewById(R.id.et);
        final ArrayAdapter  listAdapter=new ArrayAdapter<String>(this,R.layout.rows,serieslist);
        lv.setAdapter(listAdapter);
        btn_i.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				if(e.getText().toString()==null){
					Toast.makeText(v.getContext(), "NULL not allowed", Toast.LENGTH_SHORT).show();
				}
				else{
					base=openOrCreateDatabase("sim.db", MODE_PRIVATE, null);
					base.execSQL("create table if not exists student(name varchar not null);");
					base.execSQL("insert into student values('"+e.getText().toString()+"');");
					Toast.makeText(v.getContext(),e.getText().toString()+"  inserted", Toast.LENGTH_SHORT).show();
					refresh_lv();
					v.invalidate();
				}
			}

			
        });
    btn_d.setOnClickListener(new View.OnClickListener() {
		
		@Override
		public void onClick(View v) {
			base.execSQL("delete from student where name="+"'"+e.getText().toString()+"'"+";");
			refresh_lv();
		}
	});
    btn_drop.setOnClickListener(new View.OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			base.execSQL("drop table student");
			serieslist.clear();
			v.invalidate();
			v.refreshDrawableState();
		}
	});
    
    }

	protected void refresh_lv() {
		
			serieslist.clear();
	       Cursor c=base.rawQuery("select * from student;", null);
	       if(c!=null && c.moveToFirst()){
	    		int name=0;//c.getColumnIndex(base.g);
	    		do{
	    			String n=c.getString(name);
	    			if(n!=null){
	    				serieslist.add(n);
	    			}
	      		}
	    		while(c.moveToNext());
	    		}
	       	lv.invalidate();
	}
	public void showD(){
		showDialog(1000);
	}
	@Override
	protected Dialog onCreateDialog(int id) {
		Dialog dialog = null;
		AlertDialog.Builder builder = new Builder(this);
		builder.setMessage("hii");
		dialog = builder.show();
		return dialog;
	}
    
}